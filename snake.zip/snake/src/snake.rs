// [Imports]
extern crate alloc;

use alloc::collections::LinkedList;
use alloc::string::String;
use lazy_static::lazy_static;
use spin::Mutex;
use crate::interrupts::Direction;

// [Public Static Mutables]
lazy_static! {
    pub static ref SNAKE: Mutex<LinkedList<Coordinate>> = {
        let mut snake = LinkedList::new();

        snake.push_back(Coordinate {
            x: START_X,
            y: START_Y,
        });

        Mutex::new(snake)
    };
}

lazy_static! {
    pub static ref FOOD: Mutex<Coordinate> = {
        // Mirror starting position of snek
        let food = Coordinate {
            x: WIDTH - START_X + WIDTH % 2, // round up on remainder
            y: HEIGHT - START_Y + HEIGHT % 2,  // ^^
        };

        Mutex::new(food)
    };
}

// [Local Constants]
const WIDTH: u16 = 80;
const HEIGHT: u16 = 25;
const START_X: u16 = WIDTH/4 + WIDTH % 2; // round up on remainder
const START_Y: u16 = HEIGHT/2 + HEIGHT % 2; // ^^

// [Public Structs]
#[derive(Debug, Copy, Clone)]
pub struct Coordinate {
    pub x: u16,
    pub y: u16,
}

// [Public Functions]
pub fn snake_cycle() {
    move_snake();
}

pub fn new_snake() -> LinkedList<Coordinate> {
    let mut newsnake = LinkedList::new();

    newsnake.push_back(Coordinate {
        x: START_X,
        y: START_Y,
    });

    return newsnake;
}

pub fn update_display() -> String {
    let snake = SNAKE.lock();
    let food = FOOD.lock();
    let mut display = String::from("");
    for row in 1..HEIGHT+1 {
        for col in 1..WIDTH+1 {
            match (row, col) {
                (1, 1) | (HEIGHT, WIDTH) => { display += "/"  }
                (HEIGHT, 1) | (1, WIDTH) => { display += "\\" }
                (1, _) | (HEIGHT, _) => { display += "-" }
                (_, 1) | (_, WIDTH) => { display += "|" }
                _ if food.y == row && food.x == col => { display += "O" }
                _ if snake.iter().any(|segment| { segment.y == row && segment.x == col } ) => { display += "#" }
                _ => { display += " " }
            }
        }
    }

    if !display.contains(" ") { // Win condition
        crate::serial_print!("VICTORY: You eated all the apples!\n");
        crate::qemu_quit(crate::QEMU_PASS);
        crate::halt();
    }
    
    return display;
}

pub fn move_snake() {
    let mut snake = SNAKE.lock();
    let food = FOOD.lock();
    let direction = crate::interrupts::DIRECTION.lock();

    let old_head = *snake.front().unwrap();
    let next_coord = find_next_coordinate(&old_head, *direction);

    if !is_safe_tile(&next_coord, *food, &snake) {
        crate::serial_println!("GAME OVER: tried to move onto unsafe tile at {:?}", next_coord);
        crate::qemu_quit(crate::QEMU_PASS);
        crate::halt();
    }
    
    snake.push_front(next_coord);
    if !should_keep_back(&next_coord, *food) {
        snake.pop_back();
    }
}

pub fn should_keep_back(head: &Coordinate, food: Coordinate) -> bool {
    return head.x == food.x && head.y == food.y;
}

// [Local Functions]
fn find_next_coordinate(coord: &Coordinate, direction: Direction) -> Coordinate {
    let new_coord = match direction {
        Direction::Up => Coordinate {
            x: coord.x,
            y: coord.y - 1,
        },
        Direction::Down => Coordinate {
            x: coord.x,
            y: coord.y + 1,
        },
        Direction::Left => Coordinate {
            x: coord.x - 1,
            y: coord.y,
        },
        Direction::Right => Coordinate {
            x: coord.x + 1,
            y: coord.y,
        },
    };
    return new_coord;
}

fn is_safe_tile(next_coord: &Coordinate, food: Coordinate, snake: &LinkedList<Coordinate>) -> bool {
    if next_coord.x == food.x && next_coord.y == food.y { return true; } // OK to walk onto food
    if next_coord.x == 1 || next_coord.x == WIDTH || next_coord.y == 1 || next_coord.y == HEIGHT { return false; } // NOT OK to walk on border
    if snake.iter().any(|segment| { segment.x == next_coord.x && segment.y == next_coord.y }) { return false; } // NOT OK to walk on self
    return true; // OK in all other cases (empty space)
}
